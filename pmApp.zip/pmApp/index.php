<?php 
include 'header.html'; ?>
<!DOCTYPE html>
<html class="no-js"> 
    <head>
      
        <div class="slider-area">
            <div class="slider">
                <div id="bg-slider" class="owl-carousel owl-theme" style="margin: auto;">
                 
                  <div class="item"><img src="img/slider-image-0.jpg" alt="Mirror Edge"></div>
                  <div class="item"><img src="img/slider-image-2.jpg" alt="The Last of us"></div>
                  <div class="item"><img src="img/slider-image-1.jpg" alt="GTA V"></div>
                 
                </div>
            </div>
            <div class="container slider-content">
                <div class="row">
                    <div class="col-md-offset-2 col-md-8 ">
                        <h2> LA BONNE ALTERNANCE </h2>
                        <p style='font-family: "Agency FB", Calibri, "Californian FB", serif
; font-size: 2.5vw' >N'envoyer plus vos CV au hasard .<br>
                                Un 
        <a href="#mymodal4" data-toggle="modal" data-target ="#mymodal4" ><strong> marché caché</strong></a>  qu'on vous aide à debusquer .</p>
                        <div class="search-form wow pulse" data-wow-delay="0.8s">
                            <form action="" class=" form-inline">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Metier">
                                </div>
                                <div class="form-group">
                                    <select name="" id="" class="form-control">
                                        <option selected> domaine souhaité </option>
                                        <option >Graphic Design</option>
                                        <option>Web Design</option>
                                        <option>App Design</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                  <i class="fa fa-map-marker" aria-hidden="true"></i>
                                    <select name="ville" id="" class="form-control">
                                        <option selected>  <i class="fa fa-map-marker" aria-hidden="true"> Location</i></option>
                                        <option>01 Ain</option>
                                        <option>02 Aisne</option>
                                        <option>03 Allier</option>
                                        <option>04 Alpes-de-Haute-Provence</option>
                                        <option>05 Hautes-Alpes</option>
                                        <option>06 Alpes-Maritimes</option>
                                        <option>07 Ardèche</option>
                                        <option>08 Ardennes</option>
                                        <option>09 Ariège</option>
                                        <option>10 Aube</option>
                                        <option>Aude</option>
                                        <option>Aveyron</option>
                                        <option>Bouches-du-Rhône</option>
                                        <option>Calvados</option>
                                        <option>Cantal</option>
                                        <option>Charente</option>
                                        <option>Charente-Maritime</option>
                                        <option>Cher</option>
                                        <option>Corrèze</option>
                                        <option>Corse-du-Sud</option>
                                        <option>Haute-Corse</option>
                                        <option>Côte-d'Or</option>
                                        <option>Côtes-d'Armor</option>
                                        <option>Creuse</option>
                                        <option>Dordogne</option>
                                        <option>Doubs</option>
                                        <option>Drôme</option>
                                        <option>Eure</option>
                                        <option>Eure-et-Loir</option>
                                        <option>Finistère</option>
                                        <option>Gard</option>
                                        <option>Haute-Garonne</option>
                                        <option>Gers</option>
                                        <option>Gironde</option>
                                        <option>Hérault</option>
                                        <option>Ille-et-Vilaine</option>
                                        <option>Indre</option>
                                        <option>Indre-et-Loire</option>
                                        <option>Isère</option>
                                        <option>Jura</option>
                                        <option>Landes</option>
                                        <option>Loir-et-Cher</option>
                                        <option>Loire</option>
                                        <option>Haute-Loire</option>
                                        <option>Loire-Atlantique</option>
                                        <option>Loiret</option>
                                        <option>Lot</option>
                                        <option>Lot-et-Garonne</option>
                                        <option>Lozère</option>
                                        <option>Maine-et-Loire</option>
                                        <option>Manche</option>
                                        <option>Marne</option>
                                        <option>Haute-Marne</option>
                                        <option>Mayenne</option>
                                        <option>Meurthe-et-Moselle</option>
                                        <option>Meuse</option>
                                        <option>Morbihan</option>
                                        <option>Moselle</option>
                                        <option>Nièvre</option>
                                        <option>Nord</option>
                                        <option>Oise</option>
                                        <option>Orne</option>
                                        <option>Pas-de-Calais</option>
                                        <option>Puy-de-Dôme</option>
                                        <option>Pyrénées-Atlantiques</option>
                                        <option>Hautes-Pyrénées</option>
                                        <option>Pyrénées-Orientales</option>
                                        <option>Bas-Rhin</option>
                                        <option>Haut-Rhin</option>
                                        <option>Rhône</option>
                                        <option>Haute-Saône</option>
                                        <option>Saône-et-Loire</option>
                                        <option>Sarthe</option>
                                        <option>Savoie</option>
                                        <option>Haute-Savoie</option>
                                        <option>Paris</option>
                                        <option>Seine-Maritime</option>
                                        <option>Seine-et-Marne</option>
                                        <option>Yvelines</option>
                                        <option>Deux-Sèvres</option>
                                        <option>Somme</option>
                                        <option>Tarn</option>
                                        <option>Tarn-et-Garonne</option>
                                        <option>Var</option>
                                        <option>Vaucluse</option>
                                        <option>Vendée</option>
                                        <option>Vienne</option>
                                        <option>Haute-Vienne</option>
                                        <option>Vosges</option>
                                        <option>Yonne</option>
                                        <option>Territoire de Belfort</option>
                                        <option>Essonne</option>
                                        <option>Hauts-de-Seine</option>
                                        <option>Seine-Saint-Denis</option>
                                        <option>Val-de-Marne</option>
                                        <option>Val-d'Oise</option>
                                        <option>Guadeloupe</option>
                                        <option>Martinique</option>
                                        <option>Guyane</option>
                                        <option>La Réunion</option>
                                        <option>Mayotte</option>
                                    </select>

                                </div>
                                
                                <button class=" btn btn-primary" >Recherche</button><a href=""></a> type="submit" class="btn btn-primary" >


                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            </div>
        </div>
		
		
		
		
		
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/wow.js"></script>
        <script src="js/main.js"></script>

<div class="modal fade" id="mymodal4">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header ">
        <div class="titre">
     
          <h3 style="text-align: center; "> <i class="fa fa-user" hidden="true" > </i>Le saviez-vous ?</h3>

        </div>
      </div>
      <div class="modal-body">

     
          <div class="regle">
            

                <p style="text-align: center;">70% des offres ne sont pas visibles  sur le marché de l’emploi:
                <p class="gras"  style="list-style-type: disc; text-align: center;">  *Bouche-à-oreille, </p>
               <p class="gras"  style="list-style-type: disc; text-align: center;">  *Candidature spontanée, </p>
               <p class="gras"  style="list-style-type: disc; text-align: center;">  *Rencontre sur un salon, </p>
                    <p class="gras"  style="list-style-type: disc; text-align: center;">  * Prise de contact sur Internet</p> 

                      <p>  Grâce à la bonne alternance, vous avez une chance d’accéder au marché caché !</p>

            </div>
        
        </div>

         <div class="modal-footer">
        
        </div>

     

    </body>
</html>
